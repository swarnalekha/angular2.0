import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { SomeComponent,SomeDirective } from './custom.directive';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `
    <!-- The directive is applied -->
    <comp></comp>
  `
})
export class DirComponent {
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ DirComponent,SomeComponent,SomeDirective ],
	bootstrap:[ DirComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);