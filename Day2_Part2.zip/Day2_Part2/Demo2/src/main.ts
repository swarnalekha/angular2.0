import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
   selector: 'my-app';
   template:`
   <h2>My First Angular 2 App {{company}} </h2>
   <h3> Value of addition {{calculate(89,3456)}}</h3>
   <h2> {{display(company)}}</h2>
    <h2> {{"I am "+16+3+"years old"}}</h2>
   `
})

export class AppComponent {

	company:string="Capgemini";

	calculate(n1:number,n2:number):number{
	 return n1+n2;
	}

	display(name:string):string{
	 return "Thanks for visiting our page Mr. "+name;
	}
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
