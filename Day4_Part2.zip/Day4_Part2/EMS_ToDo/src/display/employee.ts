export interface Employee{
    id:number,
    name:string,
    desig:string
}