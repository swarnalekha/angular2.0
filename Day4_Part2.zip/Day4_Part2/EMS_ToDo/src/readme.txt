import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ViewEmployeeComponent } from './viewEmp/employee.component.get';
import { EmployeeComponent } from './addEmp/Employee.component';

enableProdMode();

@Component({
  selector: 'my-app',
   template:`<div>
                <nav  class='nav navbar-default'>
                    <div class='container-fluid'>
                        <ul class='nav navbar-nav'>
                            <li routerLinkActive="active"><a [routerLink]="['/home']" >Home</a></li>
                            <li routerLinkActive="active"><a [routerLink]="['/about',id]">About</a></li>
                          </ul>
                    </div>
                </nav>
            <div>
            <div class="container">
                <router-outlet></router-outlet>
            </div>`
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'addEmployee', component: EmployeeComponent },
  { path: 'viewEmployee', component: ViewEmployeeComponent }
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true })],
    declarations:[ AppComponent, HomeComponent,EmployeeComponent,ViewEmployeeComponent],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);