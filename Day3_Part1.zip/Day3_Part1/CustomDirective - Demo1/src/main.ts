import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {Component,Directive,Renderer,ElementRef,Inject,NgModule,Input,Output,EventEmitter
} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

class Joke {
  public setup: string;
  public punchline: string;
  public hide: boolean;

  constructor(setup: string, punchline: string) {
    this.setup = setup;
    this.punchline = punchline;
    this.hide = true;
  }

  toggle() {
    this.hide = !this.hide;
  }
}

@Directive({
  selector: "[ccCardHover]"
})
class CardHoverDirective {
  constructor(@Inject(ElementRef) private el: ElementRef,
              @Inject(Renderer) private renderer: Renderer) {
    renderer.setElementStyle(el.nativeElement, 'backgroundColor', 'yellow');
  }
}


@Component({
  selector: 'joke',
  template: `
			<div class="card card-block" ccCardHover>
			  <h4 class="card-title">{{data.setup}}</h4>
			  <p class="card-text"
				 [hidden]="data.hide">{{data.punchline}}</p>
			  <button (click)="data.toggle()"
				 class="btn btn-primary">Tell Me
			  </button>
			</div>
			`
})
class JokeComponent {
  @Input('joke') data: Joke;
}

@Component({
  selector: 'joke-list',
  template: `
			<joke *ngFor="let j of jokes" [joke]="j"></joke>
			`
})
class JokeListComponent {
  jokes: Joke[];

  constructor() {
    this.jokes = [
      new Joke("Who is your Favourite Cricketer?", "Captain Cool (MSD) "),
      new Joke("What was the vehicle of Neil Armstrong?", "Apollo 2 (1969)"),
      new Joke("How many known Constellations are there?", "88 (and Many more..)"),
    ];
  }
}


@Component({
  selector: 'app',
  template: `
<joke-list></joke-list>
  `
})
class AppComponent {
}

@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent,JokeComponent,JokeListComponent,CardHoverDirective  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

platformBrowserDynamic().bootstrapModule(AppModule);