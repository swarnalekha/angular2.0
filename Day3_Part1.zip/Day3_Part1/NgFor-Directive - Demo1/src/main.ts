import { Component,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
import { CountryListComponent } from './countrylistcomponent';

enableProdMode();
 
@NgModule({
  imports: [ BrowserModule, FormsModule ],
  declarations: [ CountryListComponent ],
  bootstrap: [ CountryListComponent ]
})
export class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule)