import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { Employee } from './Employee'
import { EmpComponent } from './employee.component'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

@NgModule({
  imports:[ BrowserModule, FormsModule ],
  declarations:[ EmpComponent ],
  bootstrap:[ EmpComponent ]
})
class AppModule{}


platformBrowserDynamic().bootstrapModule(AppModule);

  