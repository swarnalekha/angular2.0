//our child component
import {  Component,Input,Output,EventEmitter,OnDestroy} from '@angular/core'

@Component({
  selector: 'my-child',
  providers: [],
  template: `
    <li>{{ log }}</li>
  `,
  directives: []
})
export class ChildComponent implements OnDestroy {
  
  @Input() log: string;
  @Input() index: number;
  @Output() onDelete = new EventEmitter();
  
  ngOnDestroy() {
    console.log('child ngOnDestroy => ', this.log);
  }
  
  delete() {
    this.onDelete.emit(this.index);
  }
  
}